// Registeration form validation //


function validateForm() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var terms = document.getElementById("terms").checked;


    if (fname == "") {
        alert("First name is required");
    }

    else if (lname == "") {
        alert("Last name is required");
    }

    else if (email == "") {
        alert("Email is required");
    }

    else if (password.length < 8) {
        alert("Password must be at least 8 characters");
    }

    else if (password !== confirmPassword) {
        alert("Passwords do not match");
    }

    else if (!terms) {
        alert("You must agree to the terms & conditions");
    }

    else {
        alert("Registration successful!");
    }
    return;

}